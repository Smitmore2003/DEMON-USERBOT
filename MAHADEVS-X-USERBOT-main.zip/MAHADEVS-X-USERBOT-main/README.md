# MAHADEV X USERBOT

A POWERFUL AND SUPER USERBOT.......
<p align="center">
  <a href="https://github.com/TEAM-TANDAV-X/MAHADEVS-X-USERBOTS/fork">
    


![MAHADEV X USERBOT](https://telegra.ph/file/f6ce93cb39a345085b6b9.jpg)

### Group Support 🇮🇩
`
Click the button below to join our support group`
   <a href="https://t.me/MAHADEV_X_USERBOT"><img src="https://img.shields.io/badge/Grup%20Support%3F-MAHADEV-red?&style=flat-square?&logo=telegram" width=170px></a></p>

__Repository create by [RAM/SIDDHARTH](TANDAV_X_MAHADEV_BAM_BHOLE)__




### Deploy to Heroku

[![Deploy](https://telegra.ph/file/9737134fa5cfbdf967e0b.jpg)](https://heroku.com/deploy?template=https://github.com/TEAM-TANDAV-X/MAHADEVS-X-USERBOT)

### String Session 🖇
`
Click the button next to create your strings`
[![repl](https://telegra.ph/file/62955e5fffbd9f245f070.jpg)](https://replit.com/@TANDAVSIDDHARTH/TANDAV-USERBOT#main.py)
    
------------------------------------------------
## 𝚅𝙰𝚁𝙸𝙰𝙱𝙻𝙴𝚂 :

- `APP_ID`  =  Get this value from my.telegram.org
- `API_HASH`  =  Get this value from my.telegram.org
- `STRING_SESSION`  =  Get this by using [Repl.it](#Repl) or from [terminal](#Terminal)
- `LOGGER_ID`  =  Make A Channel And Get it's ID.
- `BOT_TOKEN`  =  Make A Bot From [@BotFather](https://t.me/botfather) and paste it's token.
- `BOT_USERNAME`  =  Get the username of that Bot made from [@Botfather](https://t.me/botfather)
------------

................
© Special credit
....................
Thank you very so much 🙏

•  TANDAV X FORCE!!!!
.....................
